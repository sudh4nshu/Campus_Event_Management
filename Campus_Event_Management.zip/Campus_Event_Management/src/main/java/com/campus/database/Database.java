package com.campus.database;

import java.sql.*;

public final class Database {
    private static final String URL = "jdbc:sqlite:campus_events.db";
    private Database() {}

    public static Connection getConnection() throws SQLException {
        Connection connection = DriverManager.getConnection(URL);
        try (Statement st = connection.createStatement()) {
            st.execute("PRAGMA foreign_keys = ON");
        }
        return connection;
    }

    public static void initialize() throws SQLException {
        try (Connection c = getConnection(); Statement st = c.createStatement()) {
            st.executeUpdate("""
                CREATE TABLE IF NOT EXISTS users (
                  id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL,
                  email TEXT NOT NULL UNIQUE, password TEXT NOT NULL,
                  role TEXT NOT NULL CHECK(role IN ('ADMIN','STUDENT')),
                  roll_number TEXT
                )""");
            st.executeUpdate("""
                CREATE TABLE IF NOT EXISTS events (
                  id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL,
                  description TEXT, event_date TEXT NOT NULL, venue TEXT NOT NULL,
                  capacity INTEGER NOT NULL CHECK(capacity > 0),
                  created_by INTEGER, FOREIGN KEY(created_by) REFERENCES users(id)
                )""");
            st.executeUpdate("""
                CREATE TABLE IF NOT EXISTS registrations (
                  id INTEGER PRIMARY KEY AUTOINCREMENT,
                  event_id INTEGER NOT NULL, student_id INTEGER NOT NULL,
                  UNIQUE(event_id, student_id),
                  FOREIGN KEY(event_id) REFERENCES events(id) ON DELETE CASCADE,
                  FOREIGN KEY(student_id) REFERENCES users(id) ON DELETE CASCADE
                )""");
            st.executeUpdate("INSERT OR IGNORE INTO users(name,email,password,role,roll_number) VALUES('Administrator','admin@campus.com','admin123','ADMIN',NULL)");
            st.executeUpdate("INSERT OR IGNORE INTO users(name,email,password,role,roll_number) VALUES('Demo Student','student@campus.com','student123','STUDENT','DEMO001')");
        }
    }
}
