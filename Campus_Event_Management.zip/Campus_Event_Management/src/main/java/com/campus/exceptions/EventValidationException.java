package com.campus.exceptions;

public class EventValidationException extends Exception {
    public EventValidationException(String message) { super(message); }
}
