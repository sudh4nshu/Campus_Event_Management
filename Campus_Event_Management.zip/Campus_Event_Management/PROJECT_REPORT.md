# PROJECT REPORT
## Campus Event Management System

### 1. Introduction
The Campus Event Management System is a desktop application developed in Java. It provides a central way for administrators to publish campus events and for students to browse events and register.

### 2. Objectives
- Maintain event information in a database.
- Provide separate administrator and student access.
- Allow students to register for available events.
- Demonstrate core Java, object-oriented programming, Swing GUI and JDBC concepts.

### 3. Technologies
- Java 17
- Java Swing and AWT
- JDBC
- SQLite database
- Maven

### 4. Modules
1. **Login module:** Authenticates a user and opens the relevant dashboard.
2. **Event management module:** Admin can add, edit, view and delete events.
3. **Student registration module:** Students can register for events and view their registrations.
4. **Database module:** Stores users, events and registrations in SQLite.

### 5. Object-Oriented Concepts
- **Encapsulation:** Model classes keep fields private and expose getters.
- **Inheritance:** `Student` and `Admin` extend the abstract `Person` class.
- **Polymorphism:** Both subclasses provide their own `getRole()` implementation.
- **Abstraction:** `Person` is abstract and `EventOperations` defines service operations.
- **Interfaces:** `EventService` implements `EventOperations`.

### 6. Java Concepts Demonstrated
- Variables, data types, operators, conditional statements and loops
- Classes, objects and constructors
- Method overriding and use of abstract classes
- Packages and access modifiers
- Exception handling with `try`, `catch`, and a custom `EventValidationException`
- Collections using `ArrayList` and the `List` interface
- JDBC connection, prepared statements, SQL queries and result sets
- Swing components, layout managers and event listeners
- Basic transaction handling for student registration

### 7. Database Design
- `users`: user identity, login details and role
- `events`: event title, description, date, venue, capacity and creator
- `registrations`: mapping between students and events; a unique constraint prevents duplicate registration

### 8. How to Execute
Install JDK 17 and Maven, extract the project, open its root directory and run `mvn clean compile`. Launch `com.campus.Main` from the IDE or run it with a Maven exec plugin. The database is initialized automatically.

### 9. Test Cases
| Test | Expected result |
|---|---|
| Valid admin login | Admin dashboard opens |
| Invalid login | Error message appears |
| Admin creates event with valid details | Event is saved and listed |
| Admin enters empty title | Validation message appears |
| Student registers for an event | Registration is saved |
| Student registers twice | Database unique constraint prevents duplicate |
| Event capacity is full | Registration is rejected |
| Admin deletes an event | Event and its registrations are removed |

### 10. Limitations and Future Scope
This is an academic prototype. Passwords are plain text, there is no email verification or password recovery, and the interface is a local desktop application. Future improvements can include password hashing, date validation, search/filter, attendance tracking, notifications, reports and a web/mobile client.

### 11. Conclusion
The project demonstrates how Java OOP, interfaces, exception handling, Swing event handling and JDBC can be combined to create a functional campus event application.
