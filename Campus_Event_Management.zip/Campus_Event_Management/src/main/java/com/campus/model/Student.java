package com.campus.model;

public class Student extends Person {
    private final String rollNumber;

    public Student(int id, String name, String email, String rollNumber) {
        super(id, name, email);
        this.rollNumber = rollNumber;
    }
    public String getRollNumber() { return rollNumber; }
    @Override public String getRole() { return "STUDENT"; }
}
