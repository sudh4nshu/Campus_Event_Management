package com.campus.gui;

import com.campus.model.*;
import com.campus.service.EventService;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class EventFrame extends JPanel {
    private final Person person;
    private final EventService service=new EventService();
    private final DefaultTableModel model=new DefaultTableModel(
        new Object[]{"ID","Title","Date (YYYY-MM-DD)","Venue","Capacity","Description"},0) {
        @Override public boolean isCellEditable(int r,int c){return false;}
    };
    private final JTable table=new JTable(model);

    public EventFrame(Person person) {
        this.person=person;setLayout(new BorderLayout(8,8));setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        add(new JScrollPane(table),BorderLayout.CENTER);
        JPanel buttons=new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton refresh=new JButton("Refresh");
        buttons.add(refresh);
        if(person instanceof Admin) {
            JButton add=new JButton("Add Event"),edit=new JButton("Edit Selected"),delete=new JButton("Delete Selected");
            buttons.add(add);buttons.add(edit);buttons.add(delete);
            add.addActionListener(e->editEvent(null));
            edit.addActionListener(e->editEvent(selectedEvent()));
            delete.addActionListener(e->deleteEvent());
        } else {
            JButton register=new JButton("Register for Selected"),mine=new JButton("My Registrations");
            buttons.add(register);buttons.add(mine);
            register.addActionListener(e->register());
            mine.addActionListener(e->showMine());
        }
        add(buttons,BorderLayout.SOUTH);refresh.addActionListener(e->loadEvents());loadEvents();
    }

    private void loadEvents() {
        try {
            model.setRowCount(0);
            for(Event e:service.getAllEvents()) model.addRow(new Object[]{e.getId(),e.getTitle(),e.getEventDate(),e.getVenue(),e.getCapacity(),e.getDescription()});
        } catch(Exception ex){error(ex);}
    }
    private Event selectedEvent() {
        int row=table.getSelectedRow();if(row<0){JOptionPane.showMessageDialog(this,"Select an event first.");return null;}
        int id=(int)model.getValueAt(row,0);
        try {for(Event e:service.getAllEvents())if(e.getId()==id)return e;}catch(Exception ex){error(ex);}
        return null;
    }
    private void editEvent(Event old) {
        if(old!=null && !(person instanceof Admin))return;
        JTextField title=new JTextField(old==null?"":old.getTitle());
        JTextField date=new JTextField(old==null?"":old.getEventDate());
        JTextField venue=new JTextField(old==null?"":old.getVenue());
        JTextField capacity=new JTextField(old==null?"50":String.valueOf(old.getCapacity()));
        JTextArea description=new JTextArea(old==null?"":old.getDescription(),4,22);
        JPanel p=new JPanel(new GridLayout(0,2,5,5));
        p.add(new JLabel("Title"));p.add(title);p.add(new JLabel("Date (YYYY-MM-DD)"));p.add(date);
        p.add(new JLabel("Venue"));p.add(venue);p.add(new JLabel("Capacity"));p.add(capacity);
        p.add(new JLabel("Description"));p.add(new JScrollPane(description));
        if(JOptionPane.showConfirmDialog(this,p,old==null?"Create Event":"Update Event",JOptionPane.OK_CANCEL_OPTION)!=JOptionPane.OK_OPTION)return;
        try {
            Event e=new Event(old==null?title.getText():title.getText(),description.getText(),date.getText(),venue.getText(),Integer.parseInt(capacity.getText()),person.getId());
            if(old==null)service.createEvent(e);else service.updateEvent(new Event(old.getId(),e.getTitle(),e.getDescription(),e.getEventDate(),e.getVenue(),e.getCapacity(),person.getId()));
            loadEvents();
        }catch(Exception ex){error(ex);}
    }
    private void deleteEvent() {
        Event e=selectedEvent();if(e==null)return;
        if(JOptionPane.showConfirmDialog(this,"Delete '"+e.getTitle()+"'?","Confirm",JOptionPane.YES_NO_OPTION)==JOptionPane.YES_OPTION)
            try{service.deleteEvent(e.getId());loadEvents();}catch(Exception ex){error(ex);}
    }
    private void register() {
        Event e=selectedEvent();if(e==null)return;
        try{service.registerStudent(e.getId(),person.getId());JOptionPane.showMessageDialog(this,"Registration successful.");}
        catch(Exception ex){error(ex);}
    }
    private void showMine() {
        try {
            List<Event> events=service.getRegisteredEvents(person.getId());
            StringBuilder b=new StringBuilder();
            for(Event e:events)b.append(e.getTitle()).append(" — ").append(e.getEventDate()).append(" at ").append(e.getVenue()).append("\n");
            JOptionPane.showMessageDialog(this,b.length()==0?"No registrations yet.":b.toString(),"My Registrations",JOptionPane.INFORMATION_MESSAGE);
        }catch(Exception ex){error(ex);}
    }
    private void error(Exception ex){JOptionPane.showMessageDialog(this,ex.getMessage(),"Error",JOptionPane.ERROR_MESSAGE);}
}
