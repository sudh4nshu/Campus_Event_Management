package com.campus.interfaces;

import com.campus.model.Event;
import java.util.List;

public interface EventOperations {
    List<Event> getAllEvents() throws Exception;
    void createEvent(Event event) throws Exception;
    void updateEvent(Event event) throws Exception;
    void deleteEvent(int eventId) throws Exception;
    void registerStudent(int eventId, int studentId) throws Exception;
    List<Event> getRegisteredEvents(int studentId) throws Exception;
}
