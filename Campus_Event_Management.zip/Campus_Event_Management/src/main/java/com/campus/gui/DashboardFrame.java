package com.campus.gui;

import com.campus.model.Person;
import javax.swing.*;
import java.awt.*;

public class DashboardFrame extends JFrame {
    public DashboardFrame(Person person) {
        setTitle("Campus Event Management - Dashboard");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);setSize(850,520);setLocationRelativeTo(null);
        JLabel welcome=new JLabel("Welcome, "+person.getName()+"  |  Role: "+person.getRole());
        welcome.setBorder(BorderFactory.createEmptyBorder(12,15,12,15));
        JButton events=new JButton("View Events / Manage Events");
        JButton logout=new JButton("Logout");
        JPanel top=new JPanel(new BorderLayout());top.add(welcome,BorderLayout.WEST);top.add(logout,BorderLayout.EAST);
        add(top,BorderLayout.NORTH);
        add(new EventFrame(person),BorderLayout.CENTER);
        logout.addActionListener(e->{dispose();new LoginFrame().setVisible(true);});
    }
}
