# Campus Event Management System

A Java Swing desktop application for managing campus events and student registrations. It uses JDBC with a local SQLite database.

## Requirements
- JDK 17 or newer
- Maven 3.8+
- Internet on the first Maven run (to download the SQLite JDBC dependency)

## Run in VS Code / terminal
1. Extract the ZIP.
2. Open the `Campus_Event_Management` folder in VS Code or a terminal.
3. Run: `mvn clean compile`
4. Run: `mvn exec:java -Dexec.mainClass="com.campus.Main"` (requires Maven Exec Plugin download), or run `com.campus.Main` from your IDE.
5. The database file `campus_events.db` is created automatically in the working directory.

## Demo accounts
- Admin: `admin@campus.com` / `admin123`
- Student: `student@campus.com` / `student123`

Change demo passwords before using this for real deployment. This academic demo stores passwords as plain text and is not suitable for production.

## Main features
- Role-based login (admin and student)
- Admin can create, edit and delete events
- Students can view events, register, and view their registrations
- Input validation and custom checked exception
- JDBC prepared statements and SQLite persistence
- Swing GUI with event-driven action listeners

## Project structure
See the `src/main/java/com/campus` package tree. The SQLite database is generated on first launch.
