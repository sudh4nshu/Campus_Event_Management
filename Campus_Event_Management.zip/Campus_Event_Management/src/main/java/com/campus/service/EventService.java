package com.campus.service;

import com.campus.database.Database;
import com.campus.exceptions.EventValidationException;
import com.campus.interfaces.EventOperations;
import com.campus.model.Event;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EventService implements EventOperations {
    private void validate(Event e) throws EventValidationException {
        if (e.getTitle() == null || e.getTitle().isBlank()) throw new EventValidationException("Event title is required.");
        if (e.getEventDate() == null || e.getEventDate().isBlank()) throw new EventValidationException("Event date is required (YYYY-MM-DD).");
        if (e.getVenue() == null || e.getVenue().isBlank()) throw new EventValidationException("Venue is required.");
        if (e.getCapacity() <= 0) throw new EventValidationException("Capacity must be greater than zero.");
    }

    @Override public List<Event> getAllEvents() throws SQLException {
        List<Event> result = new ArrayList<>();
        String sql = "SELECT e.*, (SELECT COUNT(*) FROM registrations r WHERE r.event_id=e.id) AS enrolled FROM events e ORDER BY event_date";
        try (Connection c = Database.getConnection(); Statement s = c.createStatement(); ResultSet rs = s.executeQuery(sql)) {
            while (rs.next()) result.add(map(rs));
        }
        return result;
    }

    @Override public void createEvent(Event e) throws Exception {
        validate(e);
        String sql = "INSERT INTO events(title,description,event_date,venue,capacity,created_by) VALUES(?,?,?,?,?,?)";
        try (Connection c = Database.getConnection(); PreparedStatement p = c.prepareStatement(sql)) {
            bind(p,e); p.executeUpdate();
        }
    }

    @Override public void updateEvent(Event e) throws Exception {
        validate(e);
        String sql = "UPDATE events SET title=?,description=?,event_date=?,venue=?,capacity=?,created_by=? WHERE id=?";
        try (Connection c = Database.getConnection(); PreparedStatement p = c.prepareStatement(sql)) {
            bind(p,e); p.setInt(7,e.getId());
            if (p.executeUpdate() == 0) throw new EventValidationException("Event not found.");
        }
    }

    private void bind(PreparedStatement p, Event e) throws SQLException {
        p.setString(1,e.getTitle()); p.setString(2,e.getDescription()); p.setString(3,e.getEventDate());
        p.setString(4,e.getVenue()); p.setInt(5,e.getCapacity()); p.setInt(6,e.getCreatedBy());
    }

    @Override public void deleteEvent(int id) throws SQLException {
        try (Connection c=Database.getConnection(); PreparedStatement p=c.prepareStatement("DELETE FROM events WHERE id=?")) {
            p.setInt(1,id); p.executeUpdate();
        }
    }

    @Override public void registerStudent(int eventId, int studentId) throws Exception {
        try (Connection c=Database.getConnection()) {
            c.setAutoCommit(false);
            try {
                int capacity;
                try (PreparedStatement p=c.prepareStatement("SELECT capacity FROM events WHERE id=?")) {
                    p.setInt(1,eventId); try(ResultSet rs=p.executeQuery()) {
                        if(!rs.next()) throw new EventValidationException("Event not found.");
                        capacity=rs.getInt(1);
                    }
                }
                int count;
                try(PreparedStatement p=c.prepareStatement("SELECT COUNT(*) FROM registrations WHERE event_id=?")) {
                    p.setInt(1,eventId); try(ResultSet rs=p.executeQuery()){rs.next();count=rs.getInt(1);}
                }
                if(count>=capacity) throw new EventValidationException("This event has reached its capacity.");
                try(PreparedStatement p=c.prepareStatement("INSERT INTO registrations(event_id,student_id) VALUES(?,?)")) {
                    p.setInt(1,eventId);p.setInt(2,studentId);p.executeUpdate();
                }
                c.commit();
            } catch(Exception ex) { c.rollback(); throw ex; }
        }
    }

    @Override public List<Event> getRegisteredEvents(int studentId) throws SQLException {
        List<Event> result=new ArrayList<>();
        try(Connection c=Database.getConnection(); PreparedStatement p=c.prepareStatement(
            "SELECT e.* FROM events e JOIN registrations r ON e.id=r.event_id WHERE r.student_id=? ORDER BY e.event_date")) {
            p.setInt(1,studentId); try(ResultSet rs=p.executeQuery()){while(rs.next())result.add(map(rs));}
        }
        return result;
    }

    public PersonLogin authenticate(String email, String password) throws SQLException {
        try(Connection c=Database.getConnection(); PreparedStatement p=c.prepareStatement(
            "SELECT id,name,email,role,roll_number FROM users WHERE lower(email)=lower(?) AND password=?")) {
            p.setString(1,email.trim());p.setString(2,password);
            try(ResultSet rs=p.executeQuery()) {
                if(!rs.next()) return null;
                return new PersonLogin(rs.getInt("id"),rs.getString("name"),rs.getString("email"),
                    rs.getString("role"),rs.getString("roll_number"));
            }
        }
    }

    private Event map(ResultSet rs) throws SQLException {
        return new Event(rs.getInt("id"),rs.getString("title"),rs.getString("description"),
            rs.getString("event_date"),rs.getString("venue"),rs.getInt("capacity"),rs.getInt("created_by"));
    }

    public record PersonLogin(int id,String name,String email,String role,String rollNumber) {}
}
