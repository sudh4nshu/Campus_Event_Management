package com.campus.gui;

import com.campus.model.*;
import com.campus.service.EventService;
import javax.swing.*;
import java.awt.*;

public class LoginFrame extends JFrame {
    private final JTextField email = new JTextField("admin@campus.com", 20);
    private final JPasswordField password = new JPasswordField("admin123", 20);

    public LoginFrame() {
        setTitle("Campus Event Management - Login");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(430,260); setLocationRelativeTo(null);
        JPanel panel=new JPanel(new GridBagLayout()); panel.setBorder(BorderFactory.createEmptyBorder(20,25,20,25));
        GridBagConstraints g=new GridBagConstraints();g.insets=new Insets(7,7,7,7);g.fill=GridBagConstraints.HORIZONTAL;
        g.gridx=0;g.gridy=0;g.gridwidth=2;
        JLabel heading=new JLabel("Campus Event Management",SwingConstants.CENTER);heading.setFont(new Font("SansSerif",Font.BOLD,19));panel.add(heading,g);
        g.gridwidth=1;g.gridy++;g.gridx=0;panel.add(new JLabel("Email:"),g);g.gridx=1;panel.add(email,g);
        g.gridy++;g.gridx=0;panel.add(new JLabel("Password:"),g);g.gridx=1;panel.add(password,g);
        JButton login=new JButton("Login");g.gridy++;g.gridx=0;g.gridwidth=2;panel.add(login,g);
        JLabel hint=new JLabel("<html>Demo admin: admin@campus.com / admin123<br>Demo student: student@campus.com / student123</html>");
        hint.setForeground(Color.DARK_GRAY);g.gridy++;panel.add(hint,g);
        login.addActionListener(e->authenticate()); password.addActionListener(e->authenticate());
        setContentPane(panel);
    }

    private void authenticate() {
        try {
            EventService.PersonLogin account=new EventService().authenticate(email.getText(),new String(password.getPassword()));
            if(account==null){JOptionPane.showMessageDialog(this,"Invalid email or password.");return;}
            Person person=account.role().equals("ADMIN")
                ? new Admin(account.id(),account.name(),account.email())
                : new Student(account.id(),account.name(),account.email(),account.rollNumber());
            dispose();new DashboardFrame(person).setVisible(true);
        } catch(Exception ex){JOptionPane.showMessageDialog(this,"Login error: "+ex.getMessage());}
    }
}
