package com.campus.model;

public class Event {
    private int id;
    private String title;
    private String description;
    private String eventDate;
    private String venue;
    private int capacity;
    private int createdBy;

    public Event(int id, String title, String description, String eventDate,
                 String venue, int capacity, int createdBy) {
        this.id = id; this.title = title; this.description = description;
        this.eventDate = eventDate; this.venue = venue;
        this.capacity = capacity; this.createdBy = createdBy;
    }
    public Event(String title, String description, String eventDate, String venue, int capacity, int createdBy) {
        this(0, title, description, eventDate, venue, capacity, createdBy);
    }
    public int getId() { return id; }
    public String getTitle() { return title; }
    public String getDescription() { return description; }
    public String getEventDate() { return eventDate; }
    public String getVenue() { return venue; }
    public int getCapacity() { return capacity; }
    public int getCreatedBy() { return createdBy; }
    public void setId(int id) { this.id = id; }
}
